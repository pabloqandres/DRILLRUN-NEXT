# DRILL RUN NEXT GENERATION — Integración visual RC + DTH

## Estado de esta entrega

- **Modelos GLB optimizados:** listos, validados localmente y adjuntos en este ZIP.
- **Miniaturas estáticas WebP:** listas; derivadas de los modelos optimizados, no de fotografías de otros fabricantes.
- **Código de integración:** `dist/chapter/rig-visuals.mjs`, `apply_rigs_patch.py`, `tests/rig-optimized-assets.test.mjs`.
- **GitHub:** la rama de integración contiene el cargador, la configuración visual y las pruebas. Los GLB/WebP binarios aún deben incorporarse al repositorio. No se ha fusionado ni desplegado producción.

## Por qué se redujo tanto el peso

Los archivos originales tenían ~1 millón de triángulos cada uno, texturas PNG de 4096² y una sola malla. Se simplificó la geometría mediante agrupación espacial, se eliminaron mapas enormes y se horneó una paleta neutral en colores de vértice, para evitar aspectos comerciales identificables.

| | RC Sondaje | DTH Producción |
|---|---:|---:|
| Original | 82,73 MB | 70,80 MB |
| Optimizado | 2,75 MB | 1,99 MB |
| Caras iniciales | 1.000.000 | 1.000.000 |
| Caras finales | 101.625 | 74.119 |
| Altura escala juego | 7,6 m | 8,0 m |

## Instalación (en tu checkout de DRILLRUN-NEXT)

1. Extrae este ZIP.
2. Ejecuta **una sola vez** desde la carpeta `integration/`: `python3 apply_rigs_patch.py /ruta/al/proyecto/DRILLRUN-NEXT`.
   El script modifica únicamente las llamadas visuales del juego, copia ambos GLB, ambas imágenes WebP, `rig-visuals.mjs` y las pruebas. Nunca sobrescribe archivos distintos sin avisar.
3. En la raíz del repositorio ejecuta `node --test tests/rig-optimized-assets.test.mjs`.
4. Valida en navegador compras/entrega, asignación de DTH, colliders, animación visual RC, catálogo y rendimiento móvil. La rama GitHub PR de integración ya contiene los cambios de código; faltan los archivos binarios optimizados adjuntos en este ZIP.

## Restricciones y advertencias

- **Estas son máquinas genéricas, no equipos vendidos por DRILLCO®.** No añadir marcas de competidores ni logotipos externos.
- Los modelos optimizados son **una sola malla cada uno**, porque así llegaron desde Tripo. No tienen jerarquía articulada. No se debe prometer elevación real de mástil hasta reconstruir/separar esas piezas. RC conserva el eje/cabezal procedimental móvil del juego; DTH permanece visualmente estática, con la lógica de producción sin cambios.
- Las modificaciones de apariencia se comprobaron con vistas preliminares, pero hace falta aceptación visual del usuario en el juego.
- En el PR, mientras no se copien los binarios, los equipos faltantes no reemplazan el juego existente. RC mantiene fallback procedimental. DTH no se crea en (0,0) sin zona asignada.
- Si encuentras artefactos en siluetas, sustituye GLB tras nueva aprobación sin tocar datos de economía.

## Archivos del paquete

- `dist/assets3d/drill_rc_sondaje_optimized.glb`
- `dist/assets3d/drill_dth_produccion_optimized.glb`
- `dist/assets/catalog/drill_rc_sondaje_catalog.webp`
- `dist/assets/catalog/drill_dth_produccion_catalog.webp`
- `dist/chapter/rig-visuals.mjs`
- `tests/rig-optimized-assets.test.mjs`
- `apply_rigs_patch.py`
