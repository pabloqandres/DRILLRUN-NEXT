#!/usr/bin/env python3
"""Apply small, scoped visual-only edits to existing DRILLRUN-NEXT checkout.

Run after extracting the supplied `dist/assets*` files into the repository root.
The patch never touches missions, money, saved data, equipment IDs or prices.
It refuses to patch when the expected source is missing/modified.
"""
import pathlib,sys,shutil,hashlib
root=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path.cwd()
def replace(path,old,new):
 file=root/path
 s=file.read_text('utf-8')
 if old not in s:
  if new in s:print('already patched:',path);return
  raise RuntimeError(f'Refusing to patch changed file {file}: expected code not found')
 if s.count(old)!=1:raise RuntimeError('ambiguous replacement '+str(file))
 file.write_text(s.replace(old,new),'utf-8');print('patched',path)

path=pathlib.Path('dist/chapter/game.mjs')
replace(path,"import {createDrillModel,animateDrill} from '../mission3/drill-models.mjs';", "import {createDrillModel,animateDrill} from '../mission3/drill-models.mjs';\nimport {upgradeRcRigVisual,loadRigVisual} from './rig-visuals.mjs';")
replace(path,"let m4DrillTruckModel=null,m4ParkingSpot=null,m4VisualsReady=false,m4TruckLoading=false,m4TruckCollider=null;", "let m4DrillTruckModel=null,m4ParkingSpot=null,m4VisualsReady=false,m4TruckLoading=false,m4TruckCollider=null;\nlet m4DthVisual=null,m4DthLoading=false,m4DthFailed=false,m4DthCollider=null;")
replace(path," world.scene.add(m3DrillModel);\n // Dynamic collider for drill rig", " world.scene.add(m3DrillModel);\n // Keep procedural fallback until the verified user GLB is available.\n upgradeRcRigVisual(m3DrillModel,drillId).catch(error=>console.warn('[RC] Optimized visual unavailable; keeping procedural rig:',error));\n // Dynamic collider for drill rig")
replace(path,"function updateM4Visuals(dt){\n if(!m4VisualsReady||!s?.mission4)return;",'''function updateM4Visuals(dt){
 if(!m4VisualsReady||!s?.mission4)return;
 // Production DTH becomes visible only after the existing game assigns a real
 // zone position. Do not create an invisible machine/collider at world origin.
 const dthPosition=s.mission4.productionDrill?.position;
 if(dthPosition&&!m4DthVisual&&!m4DthLoading&&!m4DthFailed){
  m4DthLoading=true;
  loadRigVisual('rig_dth_production').then(model=>{
   const position=s?.mission4?.productionDrill?.position;
   if(!position||!world)return;
   const wrapper=new T.Group();wrapper.name='production-dth-rig';wrapper.add(model);
   wrapper.position.set(position.x,0.12,position.z);
   world.scene.add(wrapper);m4DthVisual=wrapper;
   m4DthCollider={x:position.x,z:position.z,w:2.6,d:5.5,_dth:true};
   world.colliders.push(m4DthCollider);
  }).catch(error=>{
   m4DthFailed=true; // No repeated 404 every game frame.
   console.warn('[DTH] Optimized visual unavailable:',error);
  }).finally(()=>{m4DthLoading=false;});
 }
 if(m4DthVisual){
  if(!dthPosition){
   m4DthVisual.removeFromParent();m4DthVisual=null;
   const idx=world.colliders.indexOf(m4DthCollider);
   if(idx!==-1)world.colliders.splice(idx,1);
   m4DthCollider=null;
  }else{
   m4DthVisual.position.set(dthPosition.x,0.12,dthPosition.z);
   if(m4DthCollider){m4DthCollider.x=dthPosition.x;m4DthCollider.z=dthPosition.z;}
  }
 }''')
path=pathlib.Path('dist/chapter/builder-ui.mjs')
replace(path,"import {drillTruckImage} from './drilltruck-image.mjs';", "import {drillTruckImage} from './drilltruck-image.mjs';\nimport {rigCatalogImageUrl} from './rig-visuals.mjs';")
replace(path,"this.vehicleImageLoading=false;}","this.vehicleImageLoading=false;this.equipmentThumbnails=new Map();}")
replace(path," getDrillTruckThumbnail(){",''' // Async image check prevents broken img tags when an asset has not been
 // imported into the GitHub branch yet; Cards fall back to their original icon.
 getEquipmentThumbnail(id){
  if(this.equipmentThumbnails.has(id))return this.equipmentThumbnails.get(id);
  const source=rigCatalogImageUrl(id);
  if(!source)return null;
  this.equipmentThumbnails.set(id,null);
  const image=new Image();
  image.onload=()=>{
   this.equipmentThumbnails.set(id,source);
   if(this.category==='equipment'&&this.store.options&&!this.host.classList.contains('hidden'))this.store.render(this.store.options);
  };
  image.onerror=()=>{this.equipmentThumbnails.set(id,null);};
  image.src=source;
  return null;
 }
 getDrillTruckThumbnail(){''')
replace(path,"thumbnail:p=>p.kind==='module'?", "thumbnail:p=>(p.kind==='drill'||p.kind==='dthDrill')?this.getEquipmentThumbnail(p.id):p.kind==='module'?")
# Transfer optimized binaries and visual loader; never overwrite a differing
# existing asset silently. This makes the package a one-command installation.
package=pathlib.Path(__file__).resolve().parent
for path in [
 'dist/assets3d/drill_rc_sondaje_optimized.glb',
 'dist/assets3d/drill_dth_produccion_optimized.glb',
 'dist/assets/catalog/drill_rc_sondaje_catalog.webp',
 'dist/assets/catalog/drill_dth_produccion_catalog.webp',
 'dist/chapter/rig-visuals.mjs',
 'tests/rig-optimized-assets.test.mjs',
]:
 src=package/path;dest=root/path
 if not src.is_file():raise FileNotFoundError(f'Package file missing: {src}')
 dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():
  if hashlib.sha256(src.read_bytes()).digest()!=hashlib.sha256(dest.read_bytes()).digest():
   raise RuntimeError(f'Existing file differs, not overwritten: {dest}')
  print('already installed:',path)
 else:
  shutil.copyfile(src,dest)
  print('installed:',path)
print('Rig asset files and visual-only integration installed. No gameplay data changed.')
